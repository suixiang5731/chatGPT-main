# chatGPT
基于 laf 开发的 chatGPT 免费 免登录 免翻墙 点击开聊   
在线地址 https://jyf6wk-chat-gpt.site.laf.dev    
如何开发属于自己的 chatGPT ？ 参考 [三分钟拥有自己的 ChatGPT (从开发到上线)](https://zuofeng59556.github.io/my-blog/pages/quickStart/chatGPT/) 


### 免费额度用完了，我正在充值，大家先加一下群   



<img width="315" alt="wx-77aeabbd" src="https://user-images.githubusercontent.com/82700206/226231901-efd91888-f3d1-4c78-8122-aea864e42b5f.png">


## 运行项目
```
npm i
npm run dev
```
## 示例
![alt 属性文本](https://oss.laf.dev/in8dn4-image/1.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=653C1AUO2RJHDRT042DK%2F20230313%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20230313T015058Z&X-Amz-Expires=900&X-Amz-Security-Token=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJhY2Nlc3NLZXkiOiI2NTNDMUFVTzJSSkhEUlQwNDJESyIsImV4cCI6MTY3OTI3NzAyOCwicGFyZW50IjoiaW44ZG40Iiwic2Vzc2lvblBvbGljeSI6ImV5SldaWEp6YVc5dUlqb2lNakF4TWkweE1DMHhOeUlzSWxOMFlYUmxiV1Z1ZENJNlczc2lVMmxrSWpvaVlYQndMWE4wY3kxbWRXeHNMV2R5WVc1MElpd2lSV1ptWldOMElqb2lRV3hzYjNjaUxDSkJZM1JwYjI0aU9pSnpNem9xSWl3aVVtVnpiM1Z5WTJVaU9pSmhjbTQ2WVhkek9uTXpPam82S2lKOVhYMD0ifQ.BpzY44zcjWsOJ7pZesaMfVh2Ay2dIkfq62UBi5iQyvSLSKaZMeGREpTavIyj1hj5OVdMV730zvaXv1eMvKZOPw&X-Amz-Signature=fae5d99398b2ed06dc66003882623a15f38705b40c092af825ac78e71df51dde&X-Amz-SignedHeaders=host)   

![alt 属性文本](https://oss.laf.dev/in8dn4-image/2.png?X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=653C1AUO2RJHDRT042DK%2F20230313%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20230313T015237Z&X-Amz-Expires=900&X-Amz-Security-Token=eyJhbGciOiJIUzUxMiIsInR5cCI6IkpXVCJ9.eyJhY2Nlc3NLZXkiOiI2NTNDMUFVTzJSSkhEUlQwNDJESyIsImV4cCI6MTY3OTI3NzAyOCwicGFyZW50IjoiaW44ZG40Iiwic2Vzc2lvblBvbGljeSI6ImV5SldaWEp6YVc5dUlqb2lNakF4TWkweE1DMHhOeUlzSWxOMFlYUmxiV1Z1ZENJNlczc2lVMmxrSWpvaVlYQndMWE4wY3kxbWRXeHNMV2R5WVc1MElpd2lSV1ptWldOMElqb2lRV3hzYjNjaUxDSkJZM1JwYjI0aU9pSnpNem9xSWl3aVVtVnpiM1Z5WTJVaU9pSmhjbTQ2WVhkek9uTXpPam82S2lKOVhYMD0ifQ.BpzY44zcjWsOJ7pZesaMfVh2Ay2dIkfq62UBi5iQyvSLSKaZMeGREpTavIyj1hj5OVdMV730zvaXv1eMvKZOPw&X-Amz-Signature=541a4da6ea919b4bde1a6f9b654a7c4b263d0f6cde110c7fcabf046d363ffa7f&X-Amz-SignedHeaders=host)   
