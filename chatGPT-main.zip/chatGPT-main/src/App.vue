<script setup>
import { RouterView } from "vue-router";
</script>

<template>
  <RouterView />
</template>

<style scoped>
html{
  padding: 0;
  margin: 0;
}
</style>
